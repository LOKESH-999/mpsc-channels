pub mod getid;
pub mod send_mail;
// static X:i32=89;
// use lazy_static::lazy_static;
// lazy_static!{
//     pub static ref Mail:Result<(String,String ),getid::Errors<'static>>=getid::get_mail_pw();
// }
