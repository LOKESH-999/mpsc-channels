use std::fs;

mod email;
// struct Mail<'a>{
//     id:&'a str,
//     passwd:&'a str
// }
fn main() {
    // let mut v=vec![1,2,3,4,5];
    // if err.is_some(){
    //     Result
    // }
    // println!("{:?}",txt);
    println!("{:?}",email::getid::get_mail_pw());
    let mh=email::send_mail::MailHandeler::init();
    println!("{:?}",match mh {
        Ok(ref a)=>{
            // println!("{:?}",a);
            // _=(a.send_text("jordenspm@gmail.com".into(), "SAMPLE".into(), "body".into()));
            Ok(a.send_bin_attachements("jordenspm@gmail.com".into(), "subject".into(), None, "ob.pdf".into(), fs::read(r"C:\Users\LENOVO T495\Downloads\resume1.pdf").unwrap()))
        }
        Err(ref v)=>{
            Err(v)
        }
    });
    println!("90");
    let x=mh.unwrap();
    let m=x.send_file("jordenspm@gmail.com".into(), "Resume".into(), Some("Resume".into()),r"C:\Users\LENOVO T495\Downloads\resume.pdf".into());
    match m {
        Ok(a)=>{
            println!("{:?}",a.code())
        }
        Err(x)=>
        println!("{:?}",x)

    }

}

